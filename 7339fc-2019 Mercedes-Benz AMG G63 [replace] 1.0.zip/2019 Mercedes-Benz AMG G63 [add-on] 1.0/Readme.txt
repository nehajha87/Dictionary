2019 Mercedes-Benz AMG G63[replace]1.0

Model From:GTASA(Free modules) 

Converted to GTA5 by MaxMzy  

1.0 Features : 
-Good exterior and interiors 
-Driver hands on steeringwheel 
-Real reflection in the mirrors 
-All lights are working 
-Breakable Windows 

Paint 1:Body's colour
Paint 2:Roof boxes's colour
         (extra 2)
Known BUG :
-No plate
-No working dial(I don't know how)

Installation: 
---------------------------------------------------------------- 
---------------------------------------------------------------- 
replace:

1.Replace the 3 dubsta files in the following RPF:
     .\Grand Theft Auto V\x64e.rpf\levels\gta5\vehicles.rpf\